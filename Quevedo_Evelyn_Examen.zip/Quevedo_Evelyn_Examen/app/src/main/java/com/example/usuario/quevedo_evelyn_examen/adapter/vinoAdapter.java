package com.example.usuario.quevedo_evelyn_examen.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.usuario.quevedo_evelyn_examen.R;
import com.example.usuario.quevedo_evelyn_examen.modelo.vino;

import java.util.ArrayList;

public class vinoAdapter extends BaseAdapter {
    private Context contexto;
    private ArrayList <vino> listaVinos;


    public vinoAdapter(Context contexto, ArrayList<vino> listaVinos) {
        this.contexto = contexto;
        this.listaVinos = listaVinos;
    }


    @Override
    public int getCount() {
        return listaVinos.size();
    }

    @Override
    public Object getItem(int position) {
        return listaVinos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position ;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null){
            //Agregar los componentes grafiscos en el menu
            //LayoutInflater layoutInflater = (LayoutInflater) contexto.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = View.inflate(contexto, R.layout.display_vino, null);
        }
        TextView textId = convertView.findViewById(R.id.lblid);
        TextView textNombre = convertView.findViewById(R.id.lblname);


        vino vino = listaVinos.get(position);

        textId.setText(vino.getId() + "");
        textNombre.setText(vino.getName());

        return convertView;
    }

}
