package com.example.usuario.quevedo_evelyn_examen.modelo;

public class vino {

    private int id;
    private String name;
    private String year;
    private String graphes;
    private String country;
    private String region;
    private String description;
    private String picture;

    public vino(int id, String name, String year, String graphes, String country, String region, String description, String picture) {
        this.id = id;
        this.name = name;
        this.year = year;
        this.graphes = graphes;
        this.country = country;
        this.region = region;
        this.description = description;
        this.picture = picture;
    }
    public vino(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getGraphes() {
        return graphes;
    }

    public void setGraphes(String graphes) {
        this.graphes = graphes;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }
}
