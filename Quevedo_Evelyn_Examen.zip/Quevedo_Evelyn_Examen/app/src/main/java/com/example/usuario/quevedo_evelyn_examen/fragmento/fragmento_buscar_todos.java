package com.example.usuario.quevedo_evelyn_examen.fragmento;

import android.app.Dialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.usuario.quevedo_evelyn_examen.R;
import com.example.usuario.quevedo_evelyn_examen.adapter.vinoAdapter;
import com.example.usuario.quevedo_evelyn_examen.modelo.vino;
import com.example.usuario.quevedo_evelyn_examen.servicioWeb.ServicioWeb;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link fragmento_buscar_todos.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link fragmento_buscar_todos#newInstance} factory method to
 * create an instance of this fragment.
 */
public class fragmento_buscar_todos extends Fragment implements AdapterView.OnItemClickListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    ListView listView;
    ServicioWeb servicio;
    vinoAdapter adaptadorVino;
    String consultar ="https://seguimientomedico.com/licores/index.php/wines";
    List<vino> listaVinos, listaVinosItem;
    private Context contextoGlobal;
    ArrayList<vino>vinoSeleccionado;
    ArrayList<vino> productoTod;
    vino productoSeg;

    public fragmento_buscar_todos() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentoBuscarTodo.
     */
    // TODO: Rename and change types and number of parameters
    public static fragmento_buscar_todos newInstance(String param1, String param2) {
        fragmento_buscar_todos fragment = new fragmento_buscar_todos();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_fragmento_buscar_todo, container, false);

        View vista = inflater.inflate(R.layout.fragment_fragmento_buscar_todos, container, false);

        contextoGlobal = this.getActivity();
        listView = vista.findViewById(R.id.list_view);
        listView.setOnItemClickListener(this);
        mostrarListView();

        return vista;
    }

    public void mostrarListView() {
        listaVinos = new ArrayList<vino>();
        servicio = new ServicioWeb();
        servicio.execute(consultar, "1");

        try {
            String cadena=null;
            cadena = servicio.get()+"\"}]";
            JSONArray jsonObject = new JSONArray(cadena);
            ///////////////
            for (int i = 0; i < jsonObject.length(); i++) {
                //JSONObject objeto = jsonObject.getJSONObject(i);
                vino vino = new vino();
                vino.setId(Integer.parseInt(jsonObject.getJSONObject(i).getString("id")));
                vino.setName(jsonObject.getJSONObject(i).getString("name"));
              /*  vino.setAnio(Integer.parseInt(jsonObject.getJSONObject(i).getString("year")));
                //vino.setNombre(lista.getJSONObject(i).getString("name"));
                vino.setGrapes(jsonObject.getJSONObject(i).getString("grapes"));
                vino.setPais(jsonObject.getJSONObject(i).getString("country"));
                vino.setRegion(jsonObject.getJSONObject(i).getString("region"));
                vino.setDescripcion(jsonObject.getJSONObject(i).getString("description"));*/
                listaVinos.add(vino);
            }
            contextoGlobal = this.getActivity();
            adaptadorVino = new vinoAdapter(contextoGlobal, (ArrayList<vino>) listaVinos);
            listView.setAdapter(adaptadorVino);
            adaptadorVino.notifyDataSetChanged();
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        } catch (ExecutionException e1) {
            e1.printStackTrace();
        } catch (JSONException e1) {
            e1.printStackTrace();
        }

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public List<vino> obtenerProductos(){
        listaVinos = new ArrayList<vino>();
        servicio = new ServicioWeb();
        servicio.execute(consultar,"1");
        try {
            String cadena = servicio.get()+"\"}]";
            final int datos = Log.e("Datos", cadena);

            JSONArray jsonObject = new JSONArray(cadena);
            ///////////////
            for (int i = 0; i < jsonObject.length(); i++) {
                //JSONObject objeto = jsonObject.getJSONObject(i);
                vino vino = new vino();
                vino.setId(Integer.parseInt(jsonObject.getJSONObject(i).getString("id")));
                vino.setName(jsonObject.getJSONObject(i).getString("name"));
                vino.setYear(jsonObject.getJSONObject(i).getString("year"));
                //vino.setNombre(lista.getJSONObject(i).getString("name"));
                vino.setGraphes(jsonObject.getJSONObject(i).getString("grapes"));
                vino.setCountry(jsonObject.getJSONObject(i).getString("country"));
                vino.setRegion(jsonObject.getJSONObject(i).getString("region"));
                vino.setDescription(jsonObject.getJSONObject(i).getString("description"));
                listaVinos.add(vino);
            }


        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return listaVinos;
    }

    private ArrayList<vino> obtenerProductosItem(){

        productoTod = new ArrayList<vino>();
        productoSeg = new vino();
        listaVinosItem = obtenerProductos();

        for(int i=0;i<listaVinosItem.size();i++){
            productoSeg = listaVinosItem.get(i);
            productoTod.add(productoSeg);
        }return productoTod;

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        final Dialog dlg_presentar = new Dialog(this.getActivity());
        dlg_presentar.setContentView(R.layout.dialogo);
        dlg_presentar.show();

        vinoSeleccionado = obtenerProductosItem();
        final TextView cajaID = (TextView) dlg_presentar.findViewById(R.id.lblid);
        final TextView cajaNombre = (TextView) dlg_presentar.findViewById(R.id.lblname);
        final TextView cajaAnio = (TextView) dlg_presentar.findViewById(R.id.lblyear);
        final TextView cajaGrapes = (TextView) dlg_presentar.findViewById(R.id.lblgraphes);
        final TextView cajaPais = (TextView) dlg_presentar.findViewById(R.id.lblcountry);
        final TextView cajaRegion = (TextView) dlg_presentar.findViewById(R.id.lblregion);
        final TextView cajaDescripcion = (TextView) dlg_presentar.findViewById(R.id.lbldescription);

        cajaID.setText(String.valueOf(vinoSeleccionado.get(position).getId()));
        cajaNombre.setText(vinoSeleccionado.get(position).getName());
        cajaAnio.setText(vinoSeleccionado.get(position).getYear());
        cajaGrapes.setText(vinoSeleccionado.get(position).getGraphes());
        cajaPais.setText(vinoSeleccionado.get(position).getCountry());
        cajaRegion.setText(vinoSeleccionado.get(position).getRegion());
        cajaDescripcion.setText(vinoSeleccionado.get(position).getDescription());

        dlg_presentar.show();


    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}