package com.example.usuario.quevedo_evelyn_examen.interfaz;

import com.example.usuario.quevedo_evelyn_examen.fragmento.fragmento_buscar_todos;

public interface IFfragentos extends fragmento_buscar_todos.OnFragmentInteractionListener {


}
